package fifthProb;

class MyThread implements Runnable {
	public void run() {
		for(int i=0;i<50;i++) {
			System.out.println("MyThread : "+ i);
			try {
				Thread.sleep(50);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
public class ThreadEg {

	public static void main(String[] args) {
		MyThread mt = new MyThread();
		Thread t = new Thread(mt);
		t.start();
		for(int i=100;i<150;i++) {
			System.out.println("MainThread : "+i);
			try {
				Thread.sleep(40);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}
